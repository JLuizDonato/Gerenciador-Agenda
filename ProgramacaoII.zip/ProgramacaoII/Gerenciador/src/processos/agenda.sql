CREATE database agenda;
USE agenda;

create table Contato (
id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    endereco VARCHAR(255) NOT NULL
   );

INSERT INTO Contato (nome, email, endereco)
VALUES ('Teste de nome', 'teste_email@email.com', 'Teste de endereço');

SELECT contato_id;
