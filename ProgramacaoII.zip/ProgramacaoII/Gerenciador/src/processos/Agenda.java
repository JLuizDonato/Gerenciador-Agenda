package processos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class Agenda {
    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private DefaultTableModel tableModel;
    private JTable contactTable;
    private ContatoDAO contatoDAO;
    private Connection connection;
    private JButton confirmButton; // Botão de confirmação de edição

    public Agenda() {
        try {
            connection = ConnectionFactory.getConnection();
            contatoDAO = new ContatoDAO(connection);
            initialize();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Gerenciador de Contatos");
        frame.setSize(800, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createHomePanel(), "Home");
        mainPanel.add(createContactPanel(), "Contacts");

        frame.add(mainPanel, BorderLayout.CENTER);

        cardLayout.show(mainPanel, "Home");
        frame.setVisible(true);
    }

    private JPanel createHomePanel() {
        JPanel homePanel = new JPanel();
        homePanel.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Bem-vindo ao Gerenciador de Contatos", JLabel.CENTER);
        homePanel.add(welcomeLabel, BorderLayout.CENTER);

        JButton manageContactsButton = new JButton("Gerenciar Contatos");
        manageContactsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Contacts");
            }
        });
        homePanel.add(manageContactsButton, BorderLayout.SOUTH);

        return homePanel;
    }

    @SuppressWarnings("serial")
	private JPanel createContactPanel() {
        JPanel contactPanel = new JPanel(new BorderLayout());

        String[] columnNames = {"ID", "Nome", "Email", "Endereço"};
        tableModel = new DefaultTableModel(columnNames, 0);
        contactTable = new JTable(tableModel) {
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Impede a edição da coluna de ID
            }
        };
        JScrollPane scrollPane = new JScrollPane(contactTable);
        contactPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        contactPanel.add(panel, BorderLayout.SOUTH);

        JButton addButton = new JButton("Adicionar");
        panel.add(addButton);
        JButton removeButton = new JButton("Remover");
        panel.add(removeButton);
        JButton editButton = new JButton("Editar");
        panel.add(editButton);
        JButton searchButton = new JButton("Buscar");
        panel.add(searchButton);
        JButton homeButton = new JButton("Retornar à Tela Inicial");
        panel.add(homeButton);

        confirmButton = new JButton("Confirmar Edição");
        confirmButton.setVisible(false); // Botão começa invisível
        panel.add(confirmButton);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addContact();
            }
        });

        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                removeContact();
            }
        });

        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editContact();
            }
        });

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    searchContact();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });

        homeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    loadContacts(); // Recarrega todos os contatos antes de voltar para a tela inicial
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
                cardLayout.show(mainPanel, "Home");
            }
        });

        confirmButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                confirmEditContact();
            }
        });

        try {
            loadContacts();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }

        return contactPanel;
    }

    private void loadContacts() throws SQLException {
        tableModel.setRowCount(0); // Limpa a tabela
        List<Contato> contatos = contatoDAO.listar();
        for (Contato contato : contatos) {
            tableModel.addRow(new Object[]{contato.getId(), contato.getNome(), contato.getEmail(), contato.getEndereco()});
        }
    }

    private void addContact() {
        JTextField nomeField = new JTextField(10);
        JTextField emailField = new JTextField(10);
        JTextField enderecoField = new JTextField(10);

        JPanel myPanel = new JPanel();
        myPanel.add(new JLabel("Nome:"));
        myPanel.add(nomeField);
        myPanel.add(Box.createHorizontalStrut(15));
        myPanel.add(new JLabel("Email:"));
        myPanel.add(emailField);
        myPanel.add(Box.createHorizontalStrut(15));
        myPanel.add(new JLabel("Endereço:"));
        myPanel.add(enderecoField);

        int result = JOptionPane.showConfirmDialog(null, myPanel, 
                 "Adicionar Contato", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String nome = nomeField.getText();
            String email = emailField.getText();
            String endereco = enderecoField.getText();
            try {
                Contato novoContato = new Contato(0, nome, email, endereco);
                contatoDAO.inserir(novoContato);
                loadContacts();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void removeContact() {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow != -1) {
            int id = (int) tableModel.getValueAt(selectedRow, 0);
            int response = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja remover o contato de ID: " + id + "?", "Confirmar Remoção", JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {
                try {
                    contatoDAO.remover(new Contato(id, "", "", ""));
                    loadContacts();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void editContact() {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow != -1) {
            contactTable.editCellAt(selectedRow, 1); // Habilita a edição da célula Nome
            contactTable.editCellAt(selectedRow, 2); // Habilita a edição da célula Email
            contactTable.editCellAt(selectedRow, 3); // Habilita a edição da célula Endereço

            confirmButton.setVisible(true); // Torna o botão de confirmação visível
        }
    }

    private void confirmEditContact() {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow != -1) {
            TableCellEditor editor = contactTable.getCellEditor();
            if (editor != null) {
                editor.stopCellEditing();
            }

            int id = (int) tableModel.getValueAt(selectedRow, 0);
            String nome = (String) tableModel.getValueAt(selectedRow, 1);
            String email = (String) tableModel.getValueAt(selectedRow, 2);
            String endereco = (String) tableModel.getValueAt(selectedRow, 3);

            int response = JOptionPane.showConfirmDialog(frame, "Tem certeza que deseja confirmar a edição do contato de ID: " + id + "?", "Confirmar Edição", JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {
                try {
                    Contato contatoAtualizado = new Contato(id, nome, email, endereco);
                    contatoDAO.alterar(contatoAtualizado);
                    loadContacts();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }

            confirmButton.setVisible(false); // Torna o botão de confirmação invisível novamente
        }
    }

    private void searchContact() throws SQLException {
        String nomeBusca = JOptionPane.showInputDialog(frame, "Digite o nome ou inicial do contato:");
        if (nomeBusca != null && !nomeBusca.isEmpty()) {
            List<Contato> contatos = contatoDAO.listarPorNomeInicial(nomeBusca);
            tableModel.setRowCount(0); // Limpa a tabela
            for (Contato contato : contatos) {
                tableModel.addRow(new Object[]{contato.getId(), contato.getNome(), contato.getEmail(), contato.getEndereco()});
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Agenda();
            }
        });
    }
}
